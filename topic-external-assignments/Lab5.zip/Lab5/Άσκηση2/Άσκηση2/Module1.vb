﻿Module Module1
    Sub Main()
        Dim num As Integer
        Dim i As Integer
        Dim result As String = ""

        Console.Write("Δώσε ένα αριθμό από το 1 έως το 10: ")
        num = Console.ReadLine()

        For i = 1 To 10
            result &= i & " x " & num & " = " & (i * num) & vbCrLf
        Next

        Console.WriteLine(result)

        Console.WriteLine("Πατήστε Enter για έξοδο...")
        Console.ReadLine()
    End Sub
End Module