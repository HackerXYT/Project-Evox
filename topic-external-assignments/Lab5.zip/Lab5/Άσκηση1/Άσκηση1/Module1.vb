﻿Module Module1
    Sub Main()
        Dim grade As Integer

        Console.Write("Δώσε βαθμολογία φοιτητή από το 1 έως το 10: ")
        grade = Console.ReadLine()

        Select Case grade
            Case 1 To 4
                Console.WriteLine("Απορρίπτεται (βαθμός = " & grade & ")")
            Case 5 To 6
                Console.WriteLine("Καλός (βαθμός = " & grade & ")")
            Case 7 To 8
                Console.WriteLine("Λίαν Καλός (βαθμός = " & grade & ")")
            Case 9 To 10
                Console.WriteLine("Άριστα (βαθμός = " & grade & ")")
            Case Else
                Console.WriteLine("Μη έγκυρος βαθμός! Πρέπει να είναι από 1 έως 10.")
        End Select

        Console.WriteLine("Πατήστε Enter για έξοδο...")
        Console.ReadLine()
    End Sub
End Module