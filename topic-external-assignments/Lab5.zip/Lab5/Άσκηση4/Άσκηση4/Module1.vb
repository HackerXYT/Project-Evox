﻿Module Module1
    Sub Main()
        Dim username As String
        Dim password As String
        Const correctUser As String = "chris"
        Const correctPass As String = "1234"

        Do
            Console.Clear()
            Console.Write("Εισάγετε Όνομα χρήστη: ")
            username = Console.ReadLine()

            Console.Write("Εισάγετε κωδικό: ")
            password = Console.ReadLine()

            If username = correctUser AndAlso password = correctPass Then
                Console.WriteLine("Καλώς ήρθες " & username & "!")
                Exit Do
            Else
                Console.WriteLine("Λάθος στοιχεία! Προσπάθησε ξανά.")
                Console.WriteLine("Πατήστε Enter για να συνεχίσεις...")
                Console.ReadLine()
            End If
        Loop

        Console.WriteLine("Πατήστε Enter για έξοδο...")
        Console.ReadLine()
    End Sub
End Module