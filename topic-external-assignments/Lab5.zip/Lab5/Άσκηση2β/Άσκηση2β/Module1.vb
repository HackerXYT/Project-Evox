﻿Module Module1
    Sub Main()
        Dim maxNum As Integer
        Dim i As Integer, j As Integer
        Dim result As String = ""

        Console.Write("Δώσε ένα αριθμό από το 1 έως το 10: ")
        maxNum = Console.ReadLine()

        For i = 1 To maxNum
            result &= "Προπαίδεια του " & i & ":" & vbCrLf
            For j = 1 To 10
                result &= j & " x " & i & " = " & (i * j) & vbCrLf
            Next
            result &= vbCrLf
        Next

        Console.WriteLine(result)

        Console.WriteLine("Πατήστε Enter για έξοδο...")
        Console.ReadLine()
    End Sub
End Module