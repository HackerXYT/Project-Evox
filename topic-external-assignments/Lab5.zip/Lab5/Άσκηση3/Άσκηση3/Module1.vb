﻿Module Module1
    Sub Main()
        Dim balance As Double = 1000.0
        Dim amount As Double
        Dim choice As String
        Dim transactionType As String = ""

        Console.Write("Πληκτρολόγησε (Κ) για Κατάθεση ή (Α) για Ανάληψη: ")
        choice = Console.ReadLine().ToUpper()

        Console.Write("Πληκτρολόγησε το ποσό: ")
        amount = Console.ReadLine()

        Select Case choice
            Case "Κ", "K"
                balance += amount
                transactionType = "κατάθεση"
            Case "Α", "A"
                balance -= amount
                transactionType = "ανάληψη"
            Case Else
                Console.WriteLine("Μη έγκυρη επιλογή!")
                transactionType = "άγνωστη"
        End Select

        Console.WriteLine("Το ποσό που έκανες " & transactionType & " είναι: " & amount & " €")
        Console.WriteLine("Το υπόλοιπο του λογαριασμού σου είναι: " & balance & " €")

        Console.WriteLine("Πατήστε Enter για έξοδο...")
        Console.ReadLine()
    End Sub
End Module