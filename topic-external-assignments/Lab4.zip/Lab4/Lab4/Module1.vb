﻿Module Module1

    Sub Main()
        Dim Num1, Num2, result As Double
        Dim operand As Char
        Console.Write("Give the 1st number?")
        Num1 = Console.ReadLine()
        Console.Write("Give the 2nd number?")
        Num2 = Console.ReadLine()
        Console.Write("Give the operand (+,-,*)?")
        operand = Console.ReadLine()
        If operand <> "+" And operand <> "-" And operand <> "*" Then
            Console.WriteLine("Wrong operand!! Program terminates!")
            End
        End If


        If operand = "+" Then result = Num1 + Num2
        If operand = "-" Then result = Num1 - Num2
        If operand = "*" Then result = Num1 * Num2

        Console.WriteLine()
        Console.WriteLine("**********Program Output************")
        Console.WriteLine(Num1 & operand & Num2 & " = " & result)


    End Sub

End Module